<?php 
	define('HOST','localhost');
	define('USER','root');
	define('PASS','');
	define('DB','db_image_upload_test');